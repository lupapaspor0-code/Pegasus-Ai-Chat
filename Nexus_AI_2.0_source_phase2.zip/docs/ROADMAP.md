# Roadmap

## Phase 1 — Starter UI/API (included)
- Android navigation and demo chat.
- Local in-memory agent builder.
- FastAPI endpoint skeleton.
- Explicitly marks integrations as not connected.

## Phase 2 — Persistence and authentication
- Room for local app cache, SQLite/PostgreSQL for backend records.
- User login/session management.
- Authorization on all private API routes.
- Audit trail for agent runs and approvals.

## Phase 3 — Real AI providers
- Provider adapter interface on backend.
- Add one provider at a time; test errors, timeouts, token usage, and limits.
- Store secrets in environment/secret manager only.

## Phase 4 — Agent runtime
- Task/run records and explicit delegation graph.
- Tool allowlists per agent.
- Human approval gate for external actions.
- Sentra verification status backed by run artifacts.

## Phase 5 — Files
- Android Storage Access Framework upload.
- File metadata, ownership, size limits, malware/content checks where appropriate.
- Object storage with signed URLs in production.

## Phase 6 — Automation
- Durable scheduler, time zone support, retries, idempotency, pause/resume, run history.
- Start jobs disabled until owner enables them.
- Notify only to verified destinations.

## Phase 7 — Optional integrations
- Connect legacy Hermes only after documenting its API, authentication, and network boundary.
- Keep legacy Hermes and its WhatsApp gateway separate by default.
