# Nexus AI — Android Multi-Agent Starter

Fondasi awal aplikasi Android multi-AI dan multi-agent. Nama "Nexus AI" sementara dan dapat diganti.

## Status jujur
- Android app: starter UI dengan tab Chat, Agents, Files, Automation, Settings.
- Agent Builder: membuat profil agent lokal sederhana.
- Chat: UI demonstrasi; jawaban demo lokal sampai backend dikonfigurasi.
- Backend: FastAPI scaffold dengan endpoint health, agents, chat, dan jobs.
- File: tampilan placeholder; belum ada upload/sinkronisasi.
- Automation: UI untuk melihat konsep job; belum menjalankan scheduler.
- Provider AI: adapter placeholder; belum ada provider yang benar-benar terhubung.
- Hermes: sengaja tidak terhubung dan tidak mengubah instalasi Termux yang lama.

## Prasyarat
- Android Studio terbaru yang mendukung Kotlin + Jetpack Compose.
- JDK 17.
- Python 3.11+ untuk backend (opsional saat ini).

## Buka Android
1. Ekstrak ZIP.
2. Android Studio → Open → pilih folder `android-app`.
3. Tunggu Gradle Sync.
4. Jalankan ke emulator atau HP Android dengan USB debugging.
5. APK debug dapat dibuat dari Build → Build APK(s).

Belum ada APK biner siap instal di paket ini; ini adalah source project yang bisa dibangun di Android Studio.

## Jalankan backend lokal (opsional)
```bash
cd backend
python -m venv .venv
# aktifkan venv, lalu:
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000
```
Untuk menghubungkan HP ke backend di komputer, `127.0.0.1` di HP bukan komputer. Gunakan alamat LAN komputer pada jaringan tepercaya atau HTTPS deployment. Jangan membuka backend tanpa autentikasi ke internet.

## Keamanan penting
- Jangan masukkan API key ke source Android atau commit ke Git.
- Tambahkan autentikasi sebelum penggunaan nyata.
- Backend starter belum production-ready: belum ada login, rate limiting, enkripsi database, audit log lengkap, dan pengelolaan secret.
- Jangan gunakan endpoint contoh ini untuk data sensitif sebelum hardening.
