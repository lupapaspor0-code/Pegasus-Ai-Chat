package com.nexusai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080C13)
private val Panel = Color(0xFF111A27)
private val Panel2 = Color(0xFF172435)
private val Line = Color(0xFF26364A)
private val White = Color(0xFFF4F7FB)
private val Muted = Color(0xFF91A1B5)
private val Cyan = Color(0xFF75E6D0)
private val Blue = Color(0xFF6D9EFF)
private val GreenTint = Color(0xFF153B3A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }
}

private enum class Tab(val label: String) { Home("Home"), Agents("Agents"), Chat("Chat"), Files("Files"), More("More") }
private data class Agent(val name: String, val role: String, val description: String, val status: String = "LOCAL")
private data class ChatLine(val from: String, val message: String, val isUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NexusApp() {
    var tab by remember { mutableStateOf(Tab.Home) }
    var detail by remember { mutableStateOf<Agent?>(null) }
    var selectedAgent by remember { mutableStateOf("Nexus Assistant") }
    var input by remember { mutableStateOf("") }
    var builder by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newRole by remember { mutableStateOf("") }
    var newDescription by remember { mutableStateOf("") }
    var morePage by remember { mutableStateOf("") }
    val agents = remember { mutableStateListOf(
        Agent("Nexus Assistant", "General intelligence", "Your everyday AI partner for ideas, planning, and problem solving."),
        Agent("Orion", "Research analyst", "Finds patterns, compares information, and prepares research summaries."),
        Agent("Vex", "Task executor", "Turns instructions into structured steps and useful deliverables."),
        Agent("Sentra", "Quality control", "Reviews accuracy, consistency, and completeness."),
        Agent("Lyra", "Workflow coordinator", "Coordinates tasks and keeps work organized.")
    ) }
    val messages = remember { mutableStateListOf(ChatLine("Nexus Assistant", "Welcome back. What would you like to work on today?\n\nChat is currently in demo mode until an AI provider is connected.", false)) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, onPrimary = Bg, secondary = Blue, background = Bg,
        surface = Panel, onSurface = White, onBackground = White,
        surfaceVariant = Panel2, outline = Line
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(Brush.linearGradient(listOf(Cyan, Blue))), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.AllInclusive, null, tint = Bg, modifier = Modifier.size(23.dp))
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                                Text("NEXUS", color = White, fontWeight = FontWeight.Black, fontSize = 17.sp, letterSpacing = 2.sp)
                                Text("AI WORKSPACE", color = Muted, fontSize = 8.sp, letterSpacing = 2.sp)
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { tab = Tab.More; morePage = "Settings" }) {
                            Icon(Icons.Default.Tune, "Settings", tint = Muted)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Muted, tonalElevation = 0.dp) {
                    val icons = listOf(Icons.Default.SpaceDashboard, Icons.Default.Groups, Icons.Default.ChatBubbleOutline, Icons.Default.FolderOpen, Icons.Default.Menu)
                    Tab.values().forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = tab == item && detail == null,
                            onClick = { tab = item; detail = null; morePage = "" },
                            icon = { Icon(icons[i], null) },
                            label = { Text(item.label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan, selectedTextColor = Cyan,
                                indicatorColor = GreenTint, unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                when {
                    detail != null -> AgentDetail(detail!!, onBack = { detail = null }, onChat = {
                        selectedAgent = detail!!.name; detail = null; tab = Tab.Chat
                    })
                    tab == Tab.Home -> HomePage(
                        agentCount = agents.size,
                        onChat = { tab = Tab.Chat }, onAgents = { tab = Tab.Agents },
                        onFiles = { tab = Tab.Files }, onAutomation = { tab = Tab.More; morePage = "Automation" },
                        onAgent = { detail = it }, agents = agents
                    )
                    tab == Tab.Agents -> AgentsPage(agents, { builder = true }, { detail = it })
                    tab == Tab.Chat -> ChatPage(selectedAgent, { selectedAgent = it }, agents, messages, input, { input = it }) {
                        val msg = input.trim()
                        if (msg.isNotEmpty()) {
                            messages.add(ChatLine("You", msg, true))
                            messages.add(ChatLine(selectedAgent, "Demo response: pesan sudah masuk ke antarmuka, tetapi belum dikirim ke model AI. Hubungkan provider melalui backend untuk mengaktifkan jawaban AI.", false))
                            input = ""
                        }
                    }
                    tab == Tab.Files -> FilesPage()
                    else -> MorePage(morePage, { morePage = it })
                }
            }
        }

        if (builder) {
            AlertDialog(
                onDismissRequest = { builder = false }, containerColor = Panel2,
                title = { Text("Create an agent", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(newName, { newName = it }, label = { Text("Agent name") }, singleLine = true)
                        OutlinedTextField(newRole, { newRole = it }, label = { Text("Role") }, singleLine = true)
                        OutlinedTextField(newDescription, { newDescription = it }, label = { Text("Instructions") })
                        Text("Agent tersimpan lokal selama aplikasi berjalan.", color = Muted, fontSize = 11.sp)
                    }
                },
                confirmButton = { TextButton(onClick = {
                    if (newName.isNotBlank() && newRole.isNotBlank()) {
                        agents.add(Agent(newName.trim(), newRole.trim(), newDescription.ifBlank { "Custom AI agent." }))
                        newName = ""; newRole = ""; newDescription = ""; builder = false
                    }
                }) { Text("CREATE", color = Cyan) } },
                dismissButton = { TextButton(onClick = { builder = false }) { Text("CANCEL", color = Muted) } }
            )
        }
    }
}

@Composable
private fun PageIntro(kicker: String, title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(kicker.uppercase(), color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(title, color = White, fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp)
        Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun HomePage(agentCount: Int, onChat: () -> Unit, onAgents: () -> Unit, onFiles: () -> Unit, onAutomation: () -> Unit, onAgent: (Agent) -> Unit, agents: List<Agent>) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(19.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("MONDAY • YOUR WORKSPACE", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                Text("Think bigger.\nBuild smarter.", color = White, fontSize = 31.sp, lineHeight = 36.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp)).background(Brush.linearGradient(listOf(Color(0xFF173A43), Color(0xFF17243A), Color(0xFF202447)))).padding(19.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.clip(CircleShape).background(Color(0x3375E6D0)).padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Text("NEXUS INTELLIGENCE", color = Cyan, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.AutoAwesome, null, tint = Cyan, modifier = Modifier.size(22.dp))
                    }
                    Text("One space.\nMany possibilities.", color = White, fontSize = 23.sp, lineHeight = 27.sp, fontWeight = FontWeight.Bold)
                    Text("Bring your agents, conversations, and workflows together.", color = Color(0xFFC3D1DF), fontSize = 12.sp, lineHeight = 18.sp)
                    Button(onClick = onChat, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg), contentPadding = PaddingValues(horizontal = 17.dp, vertical = 10.dp)) {
                        Text("Start a conversation", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("AGENTS", agentCount.toString(), Icons.Default.Groups, Modifier.weight(1f))
                StatTile("AI STATUS", "Demo", Icons.Default.Bolt, Modifier.weight(1f))
                StatTile("WORKSPACE", "Ready", Icons.Default.VerifiedUser, Modifier.weight(1f))
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Quick access", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.weight(1f)); Text("TOOLS", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickTile("Agents", "Build your team", Icons.Default.Groups, Modifier.weight(1f), onAgents)
                QuickTile("Files", "Your documents", Icons.Default.FolderOpen, Modifier.weight(1f), onFiles)
                QuickTile("Automation", "Planned tasks", Icons.Default.Bolt, Modifier.weight(1f), onAutomation)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Your agents", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.weight(1f)); TextButton(onClick = onAgents) { Text("View all", color = Cyan, fontSize = 11.sp) }
            }
        }
        items(agents.take(3)) { agent ->
            AgentRow(agent, Modifier.fillMaxWidth().clickable { onAgent(agent) })
        }
        item { Text("Nexus AI 0.2 • Provider integration pending", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
    }
}

@Composable
private fun StatTile(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Panel).borderCard().padding(11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(17.dp))
        Text(value, color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(label, color = Muted, fontSize = 8.sp, letterSpacing = 1.sp, maxLines = 1)
    }
}

@Composable
private fun QuickTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(17.dp)).background(Panel).clickable(onClick = onClick).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(GreenTint), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(18.dp)) }
        Text(title, color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(subtitle, color = Muted, fontSize = 9.sp, maxLines = 2, lineHeight = 12.sp)
    }
}

@Composable
private fun Modifier.borderCard(): Modifier = this.then(Modifier)

@Composable
private fun AgentsPage(agents: List<Agent>, onAdd: () -> Unit, onSelect: (Agent) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { PageIntro("Your AI team", "Agent Center", "Specialized assistants, ready for your workflow.") }
            FilledTonalButton(onClick = onAdd, colors = ButtonDefaults.filledTonalButtonColors(containerColor = GreenTint, contentColor = Cyan), shape = RoundedCornerShape(13.dp)) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(17.dp)); Text(" New", fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(17.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(agents) { agent -> AgentRow(agent, Modifier.fillMaxWidth().clickable { onSelect(agent) }) }
        }
    }
}

@Composable
private fun AgentRow(agent: Agent, modifier: Modifier = Modifier) {
    Row(modifier.clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(45.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(GreenTint, Color(0xFF20314A)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.SmartToy, null, tint = Cyan, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(agent.name, color = White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(agent.role, color = Cyan, fontSize = 10.sp)
            Text(agent.description, color = Muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 14.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun AgentDetail(agent: Agent, onBack: () -> Unit, onChat: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) { Icon(Icons.Default.ArrowBack, null, tint = Cyan); Spacer(Modifier.width(6.dp)); Text("ALL AGENTS", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp) }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF173A43), Panel2))).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(22.dp)).background(GreenTint), contentAlignment = Alignment.Center) { Icon(Icons.Default.SmartToy, null, tint = Cyan, modifier = Modifier.size(38.dp)) }
            Spacer(Modifier.height(13.dp)); Text(agent.name, color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(agent.role, color = Cyan, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp)); Text("${agent.status} PROFILE", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
        }
        Text("ABOUT THIS AGENT", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
        Text(agent.description, color = White, fontSize = 14.sp, lineHeight = 21.sp)
        Spacer(Modifier.weight(1f))
        Button(onClick = onChat, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) {
            Icon(Icons.Default.Chat, null); Spacer(Modifier.width(8.dp)); Text("START CHAT", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
        Text("Demo mode • AI provider not connected", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}

@Composable
private fun ChatPage(selected: String, onAgent: (String) -> Unit, agents: List<Agent>, messages: List<ChatLine>, input: String, onInput: (String) -> Unit, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 15.dp)) {
        Spacer(Modifier.height(9.dp))
        Text("CONVERSATION", color = Muted, fontSize = 9.sp, letterSpacing = 1.6.sp)
        var expanded by remember { mutableStateOf(false) }
        Box {
            Row(Modifier.clip(RoundedCornerShape(13.dp)).background(Panel).clickable { expanded = true }.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SmartToy, null, tint = Cyan, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(8.dp)); Text(selected, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.width(7.dp)); Icon(Icons.Default.ExpandMore, null, tint = Muted)
            }
            DropdownMenu(expanded, { expanded = false }, modifier = Modifier.background(Panel2)) {
                agents.forEach { DropdownMenuItem(text = { Text(it.name, color = White) }, onClick = { onAgent(it.name); expanded = false }) }
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(top = 15.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(messages) { line ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.isUser) Arrangement.End else Arrangement.Start) {
                    Column(Modifier.widthIn(max = 310.dp).clip(RoundedCornerShape(18.dp)).background(if (line.isUser) GreenTint else Panel).padding(13.dp)) {
                        Text(line.from, color = if (line.isUser) Cyan else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp)); Text(line.message, color = White, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 9.dp).clip(RoundedCornerShape(19.dp)).background(Panel).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(value = input, onValueChange = onInput, modifier = Modifier.weight(1f).padding(horizontal = 11.dp, vertical = 12.dp), textStyle = TextStyle(color = White, fontSize = 13.sp), decorationBox = { inner -> if (input.isEmpty()) Text("Ask Nexus anything...", color = Muted, fontSize = 13.sp); inner() })
            IconButton(onClick = onSend, modifier = Modifier.size(40.dp).clip(CircleShape).background(Cyan)) { Icon(Icons.Default.ArrowUpward, "Send", tint = Bg) }
        }
    }
}

@Composable
private fun FilesPage() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageIntro("Workspace library", "Your files", "Keep documents and agent outputs together.")
        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(22.dp)).background(Panel), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(25.dp)) {
                Box(Modifier.size(66.dp).clip(RoundedCornerShape(20.dp)).background(GreenTint), contentAlignment = Alignment.Center) { Icon(Icons.Default.FolderOpen, null, tint = Cyan, modifier = Modifier.size(32.dp)) }
                Text("Nothing here yet", color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("File upload and cloud sync will appear here when the storage service is connected.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
                Text("UPLOAD NOT ENABLED", color = Cyan, fontSize = 9.sp, letterSpacing = 1.4.sp)
            }
        }
    }
}

@Composable
private fun MorePage(selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageIntro("Workspace controls", if (selected.isEmpty()) "More" else selected, "Manage automations and application settings.")
        MoreItem("Automation Center", "Schedules and agent workflows", Icons.Default.Bolt) { onSelect("Automation") }
        MoreItem("Settings & Security", "AI providers and security controls", Icons.Default.Security) { onSelect("Settings") }
        if (selected == "Automation") {
            InfoPanel("AUTOMATION STATUS", "Scheduler is not connected yet. No background tasks are currently running.")
            InfoPanel("PLANNED CAPABILITIES", "Recurring prompts • Agent handoffs • Run history • Execution controls")
        } else if (selected == "Settings") {
            InfoPanel("AI PROVIDERS", "No AI provider is connected. Provider credentials must be stored securely on the backend, never inside the APK.")
            InfoPanel("HERMES LEGACY", "Hermes remains separate. Nexus AI does not modify the Termux installation.")
            InfoPanel("SECURITY", "Demo mode • No API keys stored in APK • Backend authentication required for production.")
        } else {
            InfoPanel("NEXUS AI 0.2", "A unified workspace for AI agents, conversations, files, and automation.")
        }
    }
}

@Composable
private fun MoreItem(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Panel).clickable(onClick = onClick).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(GreenTint), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(subtitle, color = Muted, fontSize = 10.sp) }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun InfoPanel(title: String, body: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Panel).padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 1.4.sp)
        Text(body, color = White, fontSize = 12.sp, lineHeight = 18.sp)
    }
}
