from datetime import datetime, timezone
from typing import Literal
from uuid import uuid4

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Nexus AI API", version="0.1.0")

# Starter only: in-memory data resets when the process restarts.
# Add authentication, database migrations, rate limits, and audit logs before real use.
agents = [
    {"id": "nexus-assistant", "name": "Nexus Assistant", "role": "General assistant", "enabled": True},
    {"id": "orion", "name": "Orion", "role": "Research", "enabled": True},
    {"id": "vex", "name": "Vex", "role": "Execution", "enabled": True},
    {"id": "sentra", "name": "Sentra", "role": "Verification", "enabled": True},
    {"id": "lyra", "name": "Lyra", "role": "Coordinator", "enabled": True},
]
jobs = []

class AgentCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    role: str = Field(min_length=1, max_length=80)
    instructions: str = Field(default="", max_length=5000)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    agent_id: str = "nexus-assistant"
    provider: Literal["demo", "openai_compatible"] = "demo"

class JobCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    schedule: str = Field(min_length=1, max_length=100)
    prompt: str = Field(min_length=1, max_length=5000)
    enabled: bool = False

@app.get("/health")
def health():
    return {"status": "ok", "mode": "starter", "timestamp": datetime.now(timezone.utc).isoformat()}

@app.get("/v1/agents")
def list_agents():
    return {"items": agents}

@app.post("/v1/agents")
def create_agent(body: AgentCreate):
    item = {"id": str(uuid4()), "name": body.name, "role": body.role,
            "instructions": body.instructions, "enabled": True}
    agents.append(item)
    return item

@app.post("/v1/chat")
def chat(body: ChatRequest):
    if not any(a["id"] == body.agent_id for a in agents):
        raise HTTPException(status_code=404, detail="Unknown agent_id")
    # Intentionally demo-only: never pretends an external model was contacted.
    if body.provider == "demo":
        return {"mode": "demo", "agent_id": body.agent_id,
                "reply": "Backend menerima pesan, tetapi belum ada model AI/provider yang dikonfigurasi."}
    raise HTTPException(status_code=501, detail="Provider adapter not configured")

@app.get("/v1/jobs")
def list_jobs():
    return {"items": jobs}

@app.post("/v1/jobs")
def create_job(body: JobCreate):
    item = {"id": str(uuid4()), **body.model_dump(),
            "note": "Not scheduled: scheduler adapter is not configured"}
    jobs.append(item)
    return item
