# Nexus AI 0.2.0 — UI/Agent interaction pass

## Implemented
- Replaced the light palette with a dark workspace palette.
- Updated Agent Center cards to be tappable.
- Added an agent detail view with role, description, and status.
- Added a MULAI CHAT action that selects the chosen agent and opens Chat.
- Updated app version to 0.2.0 (versionCode 2).

## Still not implemented
- Real AI provider calls; chat remains an explicitly labeled demo.
- Persistent agent storage; Agent Builder remains in-memory.
- File upload/sync and automation scheduler.
- Backend authentication and production hardening.

## Build status
A debug APK has not been built in this environment because Gradle is not installed here.
Open android-app in Android Studio, sync Gradle, then run Build > Build Bundle(s) / APK(s) > Build APK(s).
