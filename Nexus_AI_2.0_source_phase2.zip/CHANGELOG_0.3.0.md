# Nexus AI 0.3.0 — Visual redesign

## UI changes
- Added a dashboard-first home screen with a gradient hero section.
- Reworked navigation into Home, Agents, Chat, Files, and More.
- Added compact status tiles and quick-access actions.
- Refined agent cards, detail screen, chat bubbles, spacing, typography, and dark color palette.
- Moved Automation and Settings into the More area.

## Functional status
- Agent cards open their detail screen.
- Start Chat selects the chosen agent and opens Chat.
- Agent creation remains local/in-memory.
- Chat remains demo-only; no AI provider is connected.
- File upload and automation scheduler remain placeholders.

## Build status
Source updated to version 0.3.0. APK compilation and Android device testing have not been performed in this environment.
